


object Task6 extends App {
  def isPalindrome[A](ls: List[A]): Boolean = ls == ls.reverse

  val l1 = List(1, 2, 4, 6, 8)
  println((l1))
  println(isPalindrome(l1))
  val l2 = List(1, 2, 4, 2, 1)
  println((l2))
  println(isPalindrome(l2))
}