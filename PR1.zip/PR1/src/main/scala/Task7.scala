

object Task7 extends App {

  def toList(f: List[Any] => List[Any]): Any => List[Any] = {
    case list: List[_] => f(list)
    case element       => List(element)
  }

  def flatten(ls: List[Any]): List[Any] = ls flatMap toList(flatten)

  val l1 = List(List(1, 2), 3, List(), List(List(List(4, 5)), 6))
  println(s"""
    список:                     => ${l1}
    сглаженный список:          => ${flatten(l1)}""")
}