


object Task5 extends App {
  def reverseBuiltin[A](ls: List[A]): List[A] = ls.reverse

  val l1 = List(1, 2, 4, 6, 8)
  println(reverseBuiltin(l1))
}