


object Task1 {
  def lastBuiltin[A](ls: List[A]):
  A = ls.last

  def main(args: Array[String]) {
    val mylist: List[String] = List("1", "2", "4", "8", "16")
    println(mylist.last)
  }

}
