

object Task8 extends App {
  def compressRecursive[A](ls: List[A]): List[A] = ls match {
    case h :: tail => h :: compressRecursive(tail.dropWhile(_ == h))
    case Nil       => Nil
  }

  val l1 = List('a', List('a'), List('a'), 'a', 'b', 'c', 'c', 'a', 'a', 'd', 'e', 'e', 'e', 'e')
  println(s"""
    список:                => ${l1}
    очищенный список:      => ${compressRecursive(l1)}""")
}