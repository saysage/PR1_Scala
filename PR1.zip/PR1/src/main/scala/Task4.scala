


object Task4 extends App {
  def lengthBuiltin[A](ls: List[A]): Int = ls.length

  val l1 = List(1, 2, 4, 6, 8)
  println(lengthBuiltin(l1))
}