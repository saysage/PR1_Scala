


object Task2 {
  def penultimateBuiltin[A](ls: List[A]): A =
    if (ls.isEmpty) throw new NoSuchElementException
    else ls.init.last

  def main(args: Array[String]) {
    val mylist: List[String] = List("1", "2", "4", "8", "16")
    print(penultimateBuiltin(mylist))
  }

}
