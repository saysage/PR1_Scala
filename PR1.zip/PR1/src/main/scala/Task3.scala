


object Task3 extends App {
  def nthBuiltin[A](n: Int, ls: List[A]): A = ls(n)

  val l1 = List(1, 2, 3, 4, 5, 6)
  println(s"""
    список:           ${l1}
    1-ый элемент:     ${nthBuiltin(0, l1)}
    2-ой элемент:     ${nthBuiltin(2, l1)}""")
}