import Task9.pack

object Task10 extends App {
  def encode[A](ls: List[A]): List[(Int, A)] =
    pack(ls) map { e => (e.length, e.head) }

  val l1 = List('a, 'a, 'a, 'a, 'b, 'c, 'c, 'a, 'a, 'd, 'e, 'e, 'e, 'e)
  println(s"""
    список:                   => ${l1}
    раскортеженный список:    => ${encode(l1)}
""")

}